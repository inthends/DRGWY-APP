import React, {Component} from 'react';
import {View } from 'react-native'; 

export default class WhiteSpace extends Component {
    render() {
        return (
            <View>
                {/*<LoadImage style={} img={this.props.img}/>*/}
            </View>
        );
    }
}
